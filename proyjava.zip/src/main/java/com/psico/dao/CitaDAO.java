package com.psico.dao;

import com.psico.model.Cita;
import com.psico.util.ConexionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CitaDAO {
    private Connection connection;

    public CitaDAO() {
        this.connection = ConexionDB.getInstance().getConnection();
    }

    public boolean registrarCita(Cita cita) {
        // Check for overlap
        if (existeCitaEnHorario(cita.getPsicologoId(), cita.getFecha())) {
            return false;
        }
        String sql = "INSERT INTO citas (paciente_id, psicologo_id, fecha, estado) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, cita.getPacienteId());
            ps.setInt(2, cita.getPsicologoId());
            ps.setTimestamp(3, new java.sql.Timestamp(cita.getFecha().getTime()));
            ps.setString(4, "PENDIENTE");
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean existeCitaEnHorario(int psicologoId, java.util.Date fecha) {
        String sql = "SELECT COUNT(*) FROM citas WHERE psicologo_id = ? AND fecha = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, psicologoId);
            ps.setTimestamp(2, new java.sql.Timestamp(fecha.getTime()));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Cita> listarCitasPorUsuario(int usuarioId, String rol) {
        List<Cita> citas = new ArrayList<>();
        String sql = "";
        if ("PACIENTE".equals(rol)) {
            sql = "SELECT c.*, p.nombre as nombre_psicologo FROM citas c JOIN usuarios p ON c.psicologo_id = p.id WHERE c.paciente_id = ?";
        } else if ("PSICOLOGO".equals(rol)) {
            sql = "SELECT c.*, p.nombre as nombre_paciente FROM citas c JOIN usuarios p ON c.paciente_id = p.id WHERE c.psicologo_id = ?";
        } else {
            return citas;
        }

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, usuarioId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Cita c = new Cita();
                c.setId(rs.getInt("id"));
                c.setPacienteId(rs.getInt("paciente_id"));
                c.setPsicologoId(rs.getInt("psicologo_id"));
                c.setFecha(rs.getTimestamp("fecha"));
                c.setEstado(rs.getString("estado"));
                if ("PACIENTE".equals(rol)) {
                    c.setNombrePsicologo(rs.getString("nombre_psicologo"));
                } else {
                    c.setNombrePaciente(rs.getString("nombre_paciente"));
                }
                citas.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return citas;
    }
}
