package com.psico.controller;

import com.psico.dao.CitaDAO;
import com.psico.dao.UsuarioDAO;
import com.psico.model.Cita;
import com.psico.model.Usuario;
import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Named
@ViewScoped
public class CitaBean implements Serializable {
    @Inject
    private AuthBean authBean;

    private CitaDAO citaDAO;
    private UsuarioDAO usuarioDAO;

    private int selectedPsicologoId;
    private Date fechaCita;
    private List<Usuario> psicologos;
    private List<Cita> misCitas;

    @PostConstruct
    public void init() {
        citaDAO = new CitaDAO();
        usuarioDAO = new UsuarioDAO();
        psicologos = usuarioDAO.listarPsicologos();
        cargarCitas();
    }

    public void cargarCitas() {
        if (authBean.getUsuario() != null) {
            misCitas = citaDAO.listarCitasPorUsuario(authBean.getUsuario().getId(), authBean.getUsuario().getRol());
        }
    }

    public void reservarCita() {
        if (selectedPsicologoId == 0 || fechaCita == null) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_WARN, "Advertencia", "Complete todos los campos"));
            return;
        }

        Cita nuevaCita = new Cita();
        nuevaCita.setPacienteId(authBean.getUsuario().getId());
        nuevaCita.setPsicologoId(selectedPsicologoId);
        nuevaCita.setFecha(fechaCita);

        if (citaDAO.registrarCita(nuevaCita)) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Éxito", "Cita reservada correctamente"));
            cargarCitas();
        } else {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Horario no disponible"));
        }
    }

    // Getters and Setters
    public int getSelectedPsicologoId() {
        return selectedPsicologoId;
    }

    public void setSelectedPsicologoId(int selectedPsicologoId) {
        this.selectedPsicologoId = selectedPsicologoId;
    }

    public Date getFechaCita() {
        return fechaCita;
    }

    public void setFechaCita(Date fechaCita) {
        this.fechaCita = fechaCita;
    }

    public List<Usuario> getPsicologos() {
        return psicologos;
    }

    public List<Cita> getMisCitas() {
        return misCitas;
    }
}
