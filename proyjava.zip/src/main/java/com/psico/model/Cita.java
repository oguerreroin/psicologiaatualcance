package com.psico.model;

import java.util.Date;

public class Cita {
    private int id;
    private int pacienteId;
    private int psicologoId;
    private Date fecha;
    private String estado;
    
    // Helper fields for display
    private String nombrePaciente;
    private String nombrePsicologo;

    public Cita() {}

    public Cita(int id, int pacienteId, int psicologoId, Date fecha, String estado) {
        this.id = id;
        this.pacienteId = pacienteId;
        this.psicologoId = psicologoId;
        this.fecha = fecha;
        this.estado = estado;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getPacienteId() { return pacienteId; }
    public void setPacienteId(int pacienteId) { this.pacienteId = pacienteId; }
    public int getPsicologoId() { return psicologoId; }
    public void setPsicologoId(int psicologoId) { this.psicologoId = psicologoId; }
    public Date getFecha() { return fecha; }
    public void setFecha(Date fecha) { this.fecha = fecha; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public String getNombrePaciente() { return nombrePaciente; }
    public void setNombrePaciente(String nombrePaciente) { this.nombrePaciente = nombrePaciente; }
    public String getNombrePsicologo() { return nombrePsicologo; }
    public void setNombrePsicologo(String nombrePsicologo) { this.nombrePsicologo = nombrePsicologo; }
}
